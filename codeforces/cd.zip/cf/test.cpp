#include <bits/stdc++.h>
#define P(X) cout<<"db "<<X<<endl;
#define ll long long
#define rep(i,n) for(i=1;i<=n;i++)
#define FO freopen("t","w",stdout);
using namespace std;

int main()
{
    int i,j,a,b,ts,cn=0,n,f=1,v;
    char s[10000];
    freopen("test.txt","r",stdin);
    printf("started\n");
    scanf("%d %s",&n,s);
    for(i=0;i<n;i++){
        for(j=0;j<n;j++)a=i+j;
    }
    printf("%d %s",n,s);
    printf("\n");
    return 0;
}
